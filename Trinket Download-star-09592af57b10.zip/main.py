from turtle import*
hideturtle()
speed(0)
Screen().bgcolor("black")
color("green")
begin_fill()
for i in range(5):
  forward(100)
  right(144)
end_fill()